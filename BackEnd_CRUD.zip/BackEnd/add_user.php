<!DOCTYPE html>
<html>
<body>

<?php

if (isset($_POST['add_user'])) {
	// echo "Nepal";exit();
	$u = $_POST['username'];
	$e = $_POST['email'];
	$p = $_POST['password'];
	$re_p = $_POST['password-re'];
	// echo 'U: '.$u.', E: '.$e.', P: '.$p;exit;
	if ($p != $re_p) {
		echo '<script type="text/javascript">alert("Password & Confirm Password don\'t match.");</script>';
	}

	$sql = "";
	$sql = "INSERT INTO `user` (`username`, `email`,`password`)
VALUES ('$u', '$e', md5('$p'))";
//echo $sql;

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "fosp_db";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

if (mysqli_query($conn, $sql)) {
    // echo "New record created successfully.";
    header('Location: list_user.php');
} else {
    echo "Error: " . $sql . "<br>" . mysqli_error($conn);
}
mysqli_close($conn);
}
?>

<h1>Add User</h1>
<form action="" method="POST" name="user">
<table>
	<tr>
		<td>Username:</td>
		<td><input type="text" name="username" placeholder="Enter Username" required="required"></td>
	</tr>
	<tr>
		<td>Email:</td>
		<td><input type="email" name="email" value="ersks@khwopa.edu.np" required="required"></td>
	</tr>
	<tr>
		<td>Password:</td>
		<td><input type="password" value="Nepal" name="password" required="required"></td>
	</tr>
	<tr>
		<td>Confirm Password:</td>
		<td><input type="password" value="Nepal" name="password-re" required="required"></td>
	</tr>
	<tr>
		<td>&nbsp;</td>
		<td><input type="submit" name="add_user" value="ADD USER"></td>
	</tr>
</table>
</form>
</body>
</html>