-- phpMyAdmin SQL Dump
-- version 4.8.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 15, 2019 at 05:28 AM
-- Server version: 10.1.37-MariaDB
-- PHP Version: 7.3.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `fosp_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE `student` (
  `id` bigint(20) NOT NULL,
  `name` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `crn` varchar(16) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'CRN',
  `dept_id` int(2) DEFAULT NULL,
  `sem_id` int(2) DEFAULT '1',
  `reg` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `batch` varchar(4) COLLATE utf8_unicode_ci DEFAULT '2019',
  `contact` text COLLATE utf8_unicode_ci NOT NULL COMMENT 'Contact No.',
  `email` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `remarks` text COLLATE utf8_unicode_ci,
  `postby_id` int(6) DEFAULT '1' COMMENT 'Post By',
  `verified` tinyint(1) DEFAULT '0',
  `verifiedby_id` int(6) DEFAULT '1' COMMENT 'Verified By',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `status` tinyint(1) DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`id`, `name`, `crn`, `dept_id`, `sem_id`, `reg`, `batch`, `contact`, `email`, `remarks`, `postby_id`, `verified`, `verifiedby_id`, `created_at`, `updated_at`, `status`) VALUES
(1, 'Bibek', 'KCE075BCT013', 3, 1, '', '2018', '9860906640', 'manandhar.bibek01@gmail.com', '', 1, 1, 1, '2018-08-21 16:24:31', '2019-07-06 22:05:39', 1),
(3, 'Shyamron', 'KCE075BCT043', 3, 1, '', '2018', '', 'dongolshyamron@gmail.com', '', 1, 1, 2, '2018-08-23 16:50:57', '2019-07-06 22:05:49', 1),
(2, 'Sarika', 'KCE075BEL040', 2, 1, '', '2018', '', 'shresthasarika@gmail.com', '', 1, 1, 3, '2018-08-22 16:33:39', '2019-07-06 22:06:00', 1);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(10) UNSIGNED NOT NULL,
  `role_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `username` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'user',
  `remarks` text COLLATE utf8mb4_unicode_ci,
  `post_by` int(11) NOT NULL DEFAULT '1',
  `is_verified` tinyint(1) NOT NULL DEFAULT '0',
  `verified_at` timestamp NULL DEFAULT NULL,
  `verified_by` int(11) DEFAULT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `status` tinyint(4) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `role_id`, `name`, `username`, `email`, `password`, `user_type`, `remarks`, `post_by`, `is_verified`, `verified_at`, `verified_by`, `remember_token`, `created_at`, `updated_at`, `status`) VALUES
(1, 0, 'Admin', 'admin', 'admin@turingsoft.com', '$2y$10$lAPUziok3dZjvNywid9RSurYPKAugOxeF/B.rZ2y36.k.EvMSc6FC', 'Admin', NULL, 1, 0, NULL, NULL, 'D5J8fagAnqtDZTiqeCDhTbInPuL9Vuvhql9IBpQwygdjnnnvf23JlHSSdbCh', NULL, NULL, 1),
(2, 0, 'Principal', 'sujanmaka', 'principal@turingsoft.com', '$2y$10$xx5vTl4jJKNCsYqjZrz7G.Z8T33K4O1RTayv0sxKzjejRWjKWu0tO', 'Principal', NULL, 1, 0, NULL, NULL, 'vDf9yL2SMwwu40ZoRw46MOODUdRSTtMdAtBSk3HhJ0Luk1LvNthCmo7dd1Rn', NULL, '2019-07-06 16:38:48', 1),
(3, 0, 'Account', 'kbpancha', 'account@turingsoft.com', '$2y$10$5b6emCzxtzdOd/Q.sJXZ.O183j/tIB5I7TrrrK8zpWHyXwR.84hVm', 'Account', NULL, 1, 0, NULL, NULL, 'VCxJFvkMoXz5xNAJKxJZy4auId1dET3PrW5yFeXZiqioF9J1IrTWZCOfyG23', NULL, NULL, 1),
(4, 0, 'Receptionist', 'sharmila', 'receptionist@turingsoft.com', '$2y$10$hbbKUIoBnjJDp4oD43Q7r.Xgpv1a9uhulX7PxgLg0QZHRk.pLzgSS', 'Receptionist', NULL, 1, 0, NULL, NULL, 'evf8lIeZ73cWrvF5ndnBMhYb2jFt4m0pK0j8riZPJokgZM6FeX0VLweGmQN7', NULL, NULL, 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `student`
--
ALTER TABLE `student`
  ADD PRIMARY KEY (`id`),
  ADD KEY `post_by` (`postby_id`),
  ADD KEY `verified_by` (`verifiedby_id`),
  ADD KEY `dept_id` (`dept_id`),
  ADD KEY `sem_id` (`sem_id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `student`
--
ALTER TABLE `student`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11193;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
